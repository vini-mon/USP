var title = document.querySelector("h1")
var texto = document.createTextNode("Batman é top")

title.appendChild(texto)