console.log(

    document.getElementById("fruta"),
    document.getElementsByClassName("carro")[0].innerHTML

)