var div = document.createElement("div");
div.innerHTML = "fazendo um teste"
div.id = "teste"

console.log(

    div

)