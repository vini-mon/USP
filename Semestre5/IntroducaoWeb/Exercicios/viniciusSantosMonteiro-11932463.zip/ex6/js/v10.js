var div = document.getElementById("algo");

div.style.backgroundColor = "blue";
div.style.width = "550px";
div.style.height = "550px";

var img = document.getElementById("imagem");

img.src = "img/teste.png";
img.alt = "Uma imagem de teste";

img.style.maxWidth = "100px"