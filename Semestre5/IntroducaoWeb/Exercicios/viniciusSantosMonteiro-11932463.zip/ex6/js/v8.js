console.log(

    document.querySelector(".fruta"),
    document.querySelector("div")

)