console.log(

    document.getElementById("vilan").querySelectorAll(".name")[1].innerHTML,
    document.getElementById("heroes").querySelectorAll(".name")[1].innerHTML

)