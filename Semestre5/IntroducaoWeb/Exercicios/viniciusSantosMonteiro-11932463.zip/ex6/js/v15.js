console.log(

    document.getElementById("araraquara").parentNode.parentNode

)
