console.log(

    document.documentElement.firstChild,
    document.documentElement.lastChild

)

console.log(

    document.body.childNodes

)